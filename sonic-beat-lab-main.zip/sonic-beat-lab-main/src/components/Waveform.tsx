import { waveformBars } from "@/lib/mock-data";
import { cn } from "@/lib/utils";

interface WaveformProps {
  seed: number;
  color: string;
  progress: number; // 0..1
  height?: number;
  bars?: number;
  dimmed?: boolean;
  className?: string;
  onScrub?: (ratio: number) => void;
  ariaLabel?: string;
}

export function Waveform({
  seed,
  color,
  progress,
  height = 64,
  bars = 160,
  dimmed = false,
  className,
  onScrub,
  ariaLabel,
}: WaveformProps) {
  const data = waveformBars(seed, bars);
  const gap = 1;
  const barWidth = 4;
  const width = bars * (barWidth + gap);
  const round = (n: number) => Math.round(n * 100) / 100;
  const playedX = round(width * Math.min(Math.max(progress, 0), 1));

  function handleClick(e: React.MouseEvent<SVGSVGElement>) {
    if (!onScrub) return;
    const rect = e.currentTarget.getBoundingClientRect();
    onScrub((e.clientX - rect.left) / rect.width);
  }

  return (
    <svg
      role={onScrub ? "slider" : "img"}
      aria-label={ariaLabel ?? "Forma de onda"}
      aria-valuenow={onScrub ? Math.round(progress * 100) : undefined}
      aria-valuemin={onScrub ? 0 : undefined}
      aria-valuemax={onScrub ? 100 : undefined}
      viewBox={`0 0 ${width} ${height}`}
      preserveAspectRatio="none"
      onClick={handleClick}
      className={cn("w-full select-none", onScrub && "cursor-pointer", className)}
      style={{ height, opacity: dimmed ? 0.28 : 1 }}
    >
      <defs>
        <clipPath id={`played-${seed}`}>
          <rect x="0" y="0" width={playedX} height={height} />
        </clipPath>
      </defs>
      <g fill="currentColor" className="text-muted-foreground/35">
        {data.map((v, i) => {
          const h = round(Math.max(2, v * height));
          return (
            <rect
              key={i}
              x={i * (barWidth + gap)}
              y={round((height - h) / 2)}
              width={barWidth}
              height={h}
              rx={1.5}
            />
          );
        })}
      </g>
      <g clipPath={`url(#played-${seed})`} fill={color}>
        {data.map((v, i) => {
          const h = round(Math.max(2, v * height));
          return (
            <rect
              key={i}
              x={i * (barWidth + gap)}
              y={round((height - h) / 2)}
              width={barWidth}
              height={h}
              rx={1.5}
            />
          );
        })}
      </g>
    </svg>
  );
}
