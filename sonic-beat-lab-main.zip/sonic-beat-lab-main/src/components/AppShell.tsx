import { Link, useNavigate } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { actions, useAppState } from "@/lib/store";
import { cn } from "@/lib/utils";

export function Logo({ className }: { className?: string }) {
  return (
    <Link to="/" className={cn("flex items-center gap-2.5", className)} aria-label="SONICVOICE — início">
      <span className="flex h-7 w-7 items-end justify-center gap-[2px] rounded-sm bg-electric/15 px-1.5 py-1.5">
        <span className="h-2 w-[3px] rounded-full bg-electric" />
        <span className="h-4 w-[3px] rounded-full bg-electric" />
        <span className="h-2.5 w-[3px] rounded-full bg-electric" />
      </span>
      <span className="font-display text-sm font-bold tracking-[0.2em] text-foreground">
        SONIC<span className="text-electric">VOICE</span>
      </span>
    </Link>
  );
}

const NAV = [
  { to: "/dashboard", label: "Projetos" },
  { to: "/upload", label: "Nova música" },
  { to: "/plans", label: "Planos" },
  { to: "/settings", label: "Configurações" },
] as const;

export function AppShell({ children, wide = false }: { children: ReactNode; wide?: boolean }) {
  const user = useAppState((s) => s.user);
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-40 border-b border-border bg-background/85 backdrop-blur">
        <div className={cn("mx-auto flex h-14 items-center gap-8 px-6", wide ? "max-w-[1600px]" : "max-w-6xl")}>
          <Logo />
          <nav className="flex items-center gap-1" aria-label="Navegação principal">
            {NAV.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                className="rounded-sm px-3 py-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
                activeProps={{ className: "text-foreground bg-secondary" }}
              >
                {item.label}
              </Link>
            ))}
          </nav>
          <div className="ml-auto flex items-center gap-3">
            {user ? (
              <>
                <div className="hidden text-right sm:block">
                  <p className="text-xs font-medium capitalize text-foreground">{user.name}</p>
                  <p className="text-[11px] uppercase tracking-wider text-electric">{user.plan}</p>
                </div>
                <button
                  onClick={() => {
                    actions.signOut();
                    navigate({ to: "/" });
                  }}
                  className="rounded-sm border border-border px-3 py-1.5 text-xs text-muted-foreground transition-colors hover:border-electric hover:text-foreground"
                >
                  Sair
                </button>
              </>
            ) : (
              <Link
                to="/login"
                className="rounded-sm bg-electric px-3 py-1.5 text-xs font-semibold text-primary-foreground"
              >
                Entrar
              </Link>
            )}
          </div>
        </div>
      </header>
      <main className={cn("mx-auto px-6 py-10", wide ? "max-w-[1600px]" : "max-w-6xl")}>{children}</main>
    </div>
  );
}
