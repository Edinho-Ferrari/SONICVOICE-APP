import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { AppShell } from "@/components/AppShell";
import { PROCESSING_STAGES, STEM_META, STEM_ORDER } from "@/lib/mock-data";
import { Waveform } from "@/components/Waveform";
import { actions, useAppState } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/processing")({
  head: () => ({
    meta: [
      { title: "Processando — SONICVOICE" },
      { name: "description", content: "Acompanhe a separação de stems da sua faixa em tempo real." },
      { property: "og:title", content: "Processando — SONICVOICE" },
      { property: "og:description", content: "Separação de stems em andamento." },
    ],
  }),
  component: ProcessingPage,
});

function ProcessingPage() {
  const navigate = useNavigate();
  const storePending = useAppState((s) => s.pendingUpload);
  // Congela o upload no mount: limpar o pendingUpload ao finalizar não deve
  // disparar o redirect de "sem arquivo".
  const pendingRef = useRef(storePending);
  const pending = pendingRef.current;
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (!pending) {
      navigate({ to: "/upload" });
      return;
    }
    const started = performance.now();
    const total = 9000;
    let raf = 0;
    const tick = (now: number) => {
      const p = Math.min(1, (now - started) / total);
      setProgress(p);
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [pending, navigate]);

  useEffect(() => {
    if (progress < 1 || !pending) return;
    const id = `prj_${Date.now().toString(36)}`;
    actions.addProject({
      id,
      title: pending.fileName.replace(/\.[a-z0-9]+$/i, ""),
      artist: "Importado",
      durationSec: pending.durationSec,
      bpm: pending.bpm,
      keySignature: pending.keySignature,
      createdAt: new Date().toISOString().slice(0, 10),
      status: "ready",
      coverHue: 256,
    });
    actions.setPendingUpload(null);
    const t = setTimeout(() => navigate({ to: "/studio/$projectId", params: { projectId: id } }), 700);
    return () => clearTimeout(t);
  }, [progress, pending, navigate]);

  const stageIndex = Math.min(PROCESSING_STAGES.length - 1, Math.floor(progress * PROCESSING_STAGES.length));

  return (
    <AppShell>
      <div className="mx-auto max-w-2xl py-8">
        <p className="font-mono text-xs uppercase tracking-[0.3em] text-electric">Etapa 2 de 3</p>
        <h1 className="mt-3 text-4xl font-bold">Separando stems</h1>
        <p className="mt-2 truncate text-sm text-muted-foreground">{pending?.fileName ?? "—"}</p>

        <div className="mt-10 rounded-md border border-border bg-surface p-6">
          <div className="flex items-baseline justify-between">
            <span className="font-mono text-5xl font-medium tabular-nums">
              {Math.round(progress * 100)}
              <span className="text-lg text-muted-foreground">%</span>
            </span>
            <span className="font-mono text-xs text-muted-foreground">
              {progress < 1 ? "processando…" : "concluído"}
            </span>
          </div>
          <div
            className="mt-5 h-1.5 w-full overflow-hidden rounded-full bg-secondary"
            role="progressbar"
            aria-valuenow={Math.round(progress * 100)}
            aria-valuemin={0}
            aria-valuemax={100}
            aria-label="Progresso da separação"
          >
            <div
              className="h-full rounded-full bg-electric transition-[width] duration-200"
              style={{ width: `${progress * 100}%` }}
            />
          </div>

          <div className="mt-8 space-y-4">
            {STEM_ORDER.map((id, i) => {
              const active = progress > (i + 1) / (STEM_ORDER.length + 1);
              return (
                <div key={id} className="flex items-center gap-4">
                  <span className="w-16 font-mono text-[11px] uppercase tracking-wider text-muted-foreground">
                    {STEM_META[id].label}
                  </span>
                  <Waveform
                    seed={STEM_META[id].seed}
                    color={STEM_META[id].token}
                    progress={active ? 1 : Math.max(0, progress * 1.4 - i * 0.2)}
                    height={28}
                    bars={90}
                    dimmed={!active && progress < 0.2}
                  />
                </div>
              );
            })}
          </div>
        </div>

        <ol className="mt-8 space-y-3">
          {PROCESSING_STAGES.map((s, i) => (
            <li key={s.label} className="flex items-start gap-3">
              <span
                className={cn(
                  "mt-1 h-2 w-2 shrink-0 rounded-full",
                  i < stageIndex || progress === 1
                    ? "bg-electric"
                    : i === stageIndex
                      ? "animate-pulse bg-electric"
                      : "bg-border",
                )}
                aria-hidden
              />
              <div>
                <p
                  className={cn(
                    "text-sm font-medium",
                    i <= stageIndex ? "text-foreground" : "text-muted-foreground",
                  )}
                >
                  {s.label}
                </p>
                <p className="text-xs text-muted-foreground">{s.detail}</p>
              </div>
            </li>
          ))}
        </ol>
      </div>
    </AppShell>
  );
}
