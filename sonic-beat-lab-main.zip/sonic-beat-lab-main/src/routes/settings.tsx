import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { actions, useAppState } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "Configurações — SONICVOICE" },
      { name: "description", content: "Ajuste conta, preferências de processamento e formato padrão de exportação." },
      { property: "og:title", content: "Configurações — SONICVOICE" },
      { property: "og:description", content: "Preferências da sua conta SONICVOICE." },
    ],
  }),
  component: SettingsPage,
});

function SettingsPage() {
  const user = useAppState((s) => s.user);
  const settings = useAppState((s) => s.settings);

  return (
    <AppShell>
      <p className="font-mono text-xs uppercase tracking-[0.3em] text-electric">Conta</p>
      <h1 className="mt-3 text-4xl font-bold">Configurações</h1>

      <div className="mt-8 grid gap-4 lg:grid-cols-2">
        <section className="rounded-md border border-border bg-surface p-6">
          <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Perfil</h2>
          <dl className="mt-4 space-y-3 text-sm">
            <div className="flex justify-between border-b border-border pb-2">
              <dt className="text-muted-foreground">Nome</dt>
              <dd className="capitalize">{user?.name ?? "Visitante"}</dd>
            </div>
            <div className="flex justify-between border-b border-border pb-2">
              <dt className="text-muted-foreground">E-mail</dt>
              <dd className="font-mono text-xs">{user?.email ?? "não autenticado"}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-muted-foreground">Plano</dt>
              <dd className="uppercase text-electric">{user?.plan ?? "free"}</dd>
            </div>
          </dl>
        </section>

        <section className="rounded-md border border-border bg-surface p-6">
          <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
            Processamento
          </h2>
          <div className="mt-4 space-y-3">
            <SwitchRow
              label="Detectar BPM e tonalidade automaticamente"
              checked={settings.autoDetectBpm}
              onChange={(v) => actions.updateSettings({ autoDetectBpm: v })}
            />
            <SwitchRow
              label="Renderização em alta qualidade"
              checked={settings.highQualityRender}
              onChange={(v) => actions.updateSettings({ highQualityRender: v })}
            />
            <SwitchRow
              label="Receber e-mail quando terminar"
              checked={settings.emailUpdates}
              onChange={(v) => actions.updateSettings({ emailUpdates: v })}
            />
          </div>
        </section>

        <section className="rounded-md border border-border bg-surface p-6">
          <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
            Formato padrão de exportação
          </h2>
          <div className="mt-4 grid grid-cols-3 gap-2">
            {(["wav", "mp3", "flac"] as const).map((f) => (
              <button
                key={f}
                onClick={() => actions.updateSettings({ defaultFormat: f })}
                aria-pressed={settings.defaultFormat === f}
                className={cn(
                  "rounded-sm border py-2.5 font-mono text-xs uppercase",
                  settings.defaultFormat === f
                    ? "border-electric bg-electric-soft text-electric"
                    : "border-border text-muted-foreground hover:text-foreground",
                )}
              >
                {f}
              </button>
            ))}
          </div>
        </section>

        <section className="rounded-md border border-destructive/40 bg-surface p-6">
          <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
            Zona de risco
          </h2>
          <p className="mt-3 text-sm text-muted-foreground">
            Apagar a conta remove todos os projetos e stems. Ação simulada nesta versão.
          </p>
          <button className="mt-4 rounded-sm border border-destructive px-4 py-2 text-sm text-destructive hover:bg-destructive/10">
            Excluir conta
          </button>
        </section>
      </div>
    </AppShell>
  );
}

function SwitchRow({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <label className="flex cursor-pointer items-center justify-between gap-4 rounded-sm border border-border px-4 py-3 text-sm">
      <span>{label}</span>
      <span className="relative inline-flex shrink-0">
        <input
          type="checkbox"
          checked={checked}
          onChange={(e) => onChange(e.target.checked)}
          className="peer sr-only"
        />
        <span
          className={cn(
            "h-5 w-9 rounded-full transition-colors peer-focus-visible:outline peer-focus-visible:outline-2 peer-focus-visible:outline-[var(--electric)]",
            checked ? "bg-electric" : "bg-secondary",
          )}
        />
        <span
          className={cn(
            "absolute top-0.5 h-4 w-4 rounded-full bg-foreground transition-all",
            checked ? "left-[1.15rem]" : "left-0.5",
          )}
        />
      </span>
    </label>
  );
}
