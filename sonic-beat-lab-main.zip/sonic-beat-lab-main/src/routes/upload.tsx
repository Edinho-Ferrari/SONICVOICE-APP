import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { AppShell } from "@/components/AppShell";
import { DEMO_TRACKS } from "@/lib/mock-data";
import { actions } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/upload")({
  head: () => ({
    meta: [
      { title: "Nova música — SONICVOICE" },
      { name: "description", content: "Envie um arquivo ou escolha uma faixa demo para separar em stems." },
      { property: "og:title", content: "Nova música — SONICVOICE" },
      { property: "og:description", content: "Envie uma faixa e separe em quatro stems." },
    ],
  }),
  component: UploadPage,
});

function UploadPage() {
  const navigate = useNavigate();
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);
  const [selected, setSelected] = useState<{ name: string; size: string; bpm: number; key: string; duration: number } | null>(
    null,
  );

  function pickFile(file: File) {
    setSelected({
      name: file.name,
      size: `${(file.size / 1024 / 1024).toFixed(1)} MB`,
      bpm: 118,
      key: "C maj",
      duration: 198,
    });
  }

  function start() {
    if (!selected) return;
    actions.setPendingUpload({
      fileName: selected.name,
      sizeLabel: selected.size,
      bpm: selected.bpm,
      keySignature: selected.key,
      durationSec: selected.duration,
    });
    navigate({ to: "/processing" });
  }

  return (
    <AppShell>
      <p className="font-mono text-xs uppercase tracking-[0.3em] text-electric">Etapa 1 de 3</p>
      <h1 className="mt-3 text-4xl font-bold">Nova música</h1>
      <p className="mt-2 text-sm text-muted-foreground">
        Arquivos de até 50 MB em MP3, WAV ou FLAC. Nesta demonstração nenhum áudio é enviado.
      </p>

      <div className="mt-8 grid gap-8 lg:grid-cols-[1.4fr_1fr]">
        <div>
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setDragging(true);
            }}
            onDragLeave={() => setDragging(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragging(false);
              const f = e.dataTransfer.files?.[0];
              if (f) pickFile(f);
            }}
            className={cn(
              "rounded-md border-2 border-dashed p-14 text-center transition-colors",
              dragging ? "border-electric bg-electric-soft" : "border-border bg-surface",
            )}
          >
            <div className="mx-auto flex h-12 w-12 items-end justify-center gap-1" aria-hidden>
              {[10, 26, 18, 34, 14].map((h, i) => (
                <span key={i} className="w-1.5 rounded-full bg-electric" style={{ height: h }} />
              ))}
            </div>
            <p className="mt-6 text-base font-medium">Arraste o arquivo aqui</p>
            <p className="mt-1 text-sm text-muted-foreground">ou selecione do seu computador</p>
            <button
              onClick={() => inputRef.current?.click()}
              className="mt-6 rounded-sm border border-border px-5 py-2.5 text-sm font-medium hover:border-electric"
            >
              Escolher arquivo
            </button>
            <input
              ref={inputRef}
              type="file"
              accept="audio/*"
              className="sr-only"
              aria-label="Selecionar arquivo de áudio"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) pickFile(f);
              }}
            />
          </div>

          {selected && (
            <div className="mt-6 rounded-md border border-electric/40 bg-surface p-5">
              <div className="flex items-center justify-between gap-4">
                <div className="min-w-0">
                  <p className="truncate font-medium">{selected.name}</p>
                  <p className="font-mono text-xs text-muted-foreground">
                    {selected.size} · {selected.bpm} BPM · {selected.key}
                  </p>
                </div>
                <button
                  onClick={start}
                  className="shrink-0 rounded-sm bg-electric px-5 py-2.5 text-sm font-semibold text-primary-foreground"
                >
                  Separar stems
                </button>
              </div>
            </div>
          )}
        </div>

        <aside className="rounded-md border border-border bg-surface p-5">
          <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
            Faixas de demonstração
          </h2>
          <div className="mt-4 space-y-2">
            {DEMO_TRACKS.map((t) => (
              <button
                key={t.name}
                onClick={() =>
                  setSelected({ name: t.name, size: t.size, bpm: t.bpm, key: t.key, duration: t.duration })
                }
                className={cn(
                  "w-full rounded-sm border px-4 py-3 text-left transition-colors",
                  selected?.name === t.name
                    ? "border-electric bg-electric-soft"
                    : "border-border hover:border-muted-foreground",
                )}
              >
                <p className="truncate text-sm font-medium">{t.name}</p>
                <p className="font-mono text-[11px] text-muted-foreground">
                  {t.size} · {t.bpm} BPM · {t.key}
                </p>
              </button>
            ))}
          </div>
          <p className="mt-5 text-xs leading-relaxed text-muted-foreground">
            O processamento é simulado: nenhuma IA real ou upload acontece nesta versão.
          </p>
        </aside>
      </div>
    </AppShell>
  );
}
