import { createFileRoute, Link } from "@tanstack/react-router";
import { Logo } from "@/components/AppShell";
import { Waveform } from "@/components/Waveform";
import { STEM_META, STEM_ORDER } from "@/lib/mock-data";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "SONICVOICE — Separe stems e mixe no navegador" },
      {
        name: "description",
        content:
          "Envie uma música e receba vocal, bateria, baixo e instrumentos separados, prontos para mixar em um studio web premium.",
      },
      { property: "og:title", content: "SONICVOICE — Separe stems e mixe no navegador" },
      {
        property: "og:description",
        content: "Separação de stems com studio de mixagem, loop, metrônomo e exportação.",
      },
    ],
  }),
  component: Landing,
});

function Landing() {
  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-40 border-b border-border bg-background/80 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center px-6">
          <Logo />
          <nav className="ml-auto flex items-center gap-2" aria-label="Navegação">
            <Link to="/plans" className="px-3 py-2 text-sm text-muted-foreground hover:text-foreground">
              Planos
            </Link>
            <Link to="/login" className="px-3 py-2 text-sm text-muted-foreground hover:text-foreground">
              Entrar
            </Link>
            <Link
              to="/signup"
              className="rounded-sm bg-electric px-4 py-2 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90"
            >
              Criar conta
            </Link>
          </nav>
        </div>
      </header>

      <section className="relative overflow-hidden border-b border-border">
        <div className="grid-noise pointer-events-none absolute inset-0 opacity-60" aria-hidden />
        <div className="relative mx-auto max-w-6xl px-6 pb-24 pt-24">
          <p className="font-mono text-xs uppercase tracking-[0.35em] text-electric">
            separação de stems · studio web
          </p>
          <h1 className="mt-6 max-w-3xl text-5xl leading-[1.05] font-bold md:text-7xl">
            Abra qualquer música
            <br />
            em <span className="text-electric">quatro camadas</span>.
          </h1>
          <p className="mt-6 max-w-xl text-lg text-muted-foreground">
            SONICVOICE separa vocal, bateria, baixo e instrumentos, e entrega tudo em um studio de
            mixagem no navegador — com loop, metrônomo e exportação.
          </p>
          <div className="mt-10 flex flex-wrap items-center gap-3">
            <Link
              to="/signup"
              className="glow-electric rounded-sm bg-electric px-6 py-3 text-sm font-semibold text-primary-foreground"
            >
              Começar agora
            </Link>
            <Link
              to="/dashboard"
              className="rounded-sm border border-border px-6 py-3 text-sm font-medium text-foreground hover:border-electric"
            >
              Ver demonstração
            </Link>
          </div>

          <div className="mt-16 rounded-md border border-border bg-surface p-5">
            <div className="mb-4 flex items-center justify-between">
              <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
                Neon Rain · 124 BPM · A min
              </p>
              <p className="font-mono text-xs text-electric">4 stems</p>
            </div>
            <div className="space-y-3">
              {STEM_ORDER.map((id, i) => (
                <div key={id} className="flex items-center gap-4">
                  <span className="w-16 font-mono text-[11px] uppercase tracking-wider text-muted-foreground">
                    {STEM_META[id].label}
                  </span>
                  <Waveform
                    seed={STEM_META[id].seed}
                    color={STEM_META[id].token}
                    progress={0.42 - i * 0.04}
                    height={40}
                    bars={110}
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="border-b border-border">
        <div className="mx-auto grid max-w-6xl gap-px bg-border px-6 py-0 md:grid-cols-3">
          {[
            {
              n: "01",
              t: "Envie a faixa",
              d: "MP3, WAV ou FLAC. A análise detecta BPM e tonalidade automaticamente.",
            },
            {
              n: "02",
              t: "Deixe separar",
              d: "Quatro stems isolados em minutos, com waveform própria para cada camada.",
            },
            {
              n: "03",
              t: "Mixe e exporte",
              d: "Volume, pan, mute, solo, loop e metrônomo. Exporte stems ou a mixagem.",
            },
          ].map((s) => (
            <article key={s.n} className="bg-background px-8 py-14">
              <p className="font-mono text-xs text-electric">{s.n}</p>
              <h2 className="mt-4 text-xl font-bold">{s.t}</h2>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{s.d}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 py-24">
        <div className="flex flex-col items-start justify-between gap-6 rounded-md border border-border bg-surface p-10 md:flex-row md:items-center">
          <div>
            <h2 className="text-3xl font-bold">Pronto para abrir sua primeira música?</h2>
            <p className="mt-2 text-muted-foreground">5 músicas por mês no plano Free, sem cartão.</p>
          </div>
          <Link
            to="/signup"
            className="rounded-sm bg-electric px-6 py-3 text-sm font-semibold text-primary-foreground"
          >
            Criar conta grátis
          </Link>
        </div>
      </section>

      <footer className="border-t border-border">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-4 px-6 py-8">
          <Logo />
          <p className="text-xs text-muted-foreground">
            © 2026 SONICVOICE. Demonstração com dados simulados.
          </p>
        </div>
      </footer>
    </div>
  );
}
