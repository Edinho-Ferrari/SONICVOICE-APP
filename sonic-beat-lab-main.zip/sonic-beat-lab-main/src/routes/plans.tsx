import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import {
  COMPARISON,
  PLANS,
  STUDIO_COMPARISON_NOTE,
  SUBSCRIPTION_SOON_MESSAGE,
  type CompareValue,
} from "@/lib/pricing";
import { useAppState } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/plans")({
  head: () => ({
    meta: [
      { title: "Planos — SONICVOICE" },
      {
        name: "description",
        content: "Free, Pro e Studio: 5, 30 ou separações ilimitadas de stems por mês.",
      },
      { property: "og:title", content: "Planos — SONICVOICE" },
      { property: "og:description", content: "Planos de separação de stems do SONICVOICE." },
    ],
  }),
  component: PlansPage,
});

function CompareCell({ value }: { value: CompareValue }) {
  if (typeof value === "boolean") {
    return value ? (
      <span className="text-electric" aria-label="Sim">
        Sim
      </span>
    ) : (
      <span className="text-muted-foreground" aria-label="Não">
        Não
      </span>
    );
  }
  return <span className="text-foreground">{value}</span>;
}

function PlansPage() {
  const user = useAppState((s) => s.user);

  return (
    <AppShell>
      <div className="text-center">
        <p className="font-mono text-xs uppercase tracking-[0.3em] text-electric">Planos</p>
        <h1 className="mt-3 text-4xl font-bold">Escolha o volume do seu estúdio</h1>
        <p className="mx-auto mt-3 max-w-xl text-sm text-muted-foreground">
          O sistema de pagamentos será disponibilizado em uma próxima etapa.
        </p>
      </div>

      <div className="mt-10 grid gap-4 md:grid-cols-3">
        {PLANS.map((p) => {
          const current = user?.plan === p.id;
          return (
            <div
              key={p.id}
              className={cn(
                "flex flex-col rounded-md border bg-surface p-6",
                p.highlight ? "border-electric glow-electric" : "border-border",
              )}
            >
              <div className="flex items-center justify-between gap-3">
                <h2 className="text-lg font-bold">{p.name}</h2>
                {p.badge && (
                  <span
                    className={cn(
                      "rounded-full px-2.5 py-1 text-[10px] uppercase tracking-wider",
                      p.highlight
                        ? "bg-electric-soft text-electric"
                        : "border border-border text-muted-foreground",
                    )}
                  >
                    {p.badge}
                  </span>
                )}
              </div>
              <p className="mt-1 text-xs text-muted-foreground">{p.tagline}</p>
              <p className="mt-6 font-display text-4xl font-bold">
                {p.price}
                <span className="text-base font-normal text-muted-foreground">
                  {p.period === "Grátis" ? "" : p.period}
                </span>
              </p>
              {p.period === "Grátis" && (
                <p className="mt-1 text-sm text-muted-foreground">Grátis</p>
              )}
              {p.billingNotes?.map((n) => (
                <p key={n} className="mt-1 text-xs text-muted-foreground">
                  {n}
                </p>
              ))}
              <ul className="mt-6 flex-1 space-y-2.5 text-sm text-muted-foreground">
                {p.features.map((f) => (
                  <li key={f} className="flex gap-2">
                    <span className="text-electric" aria-hidden>
                      ·
                    </span>
                    {f}
                  </li>
                ))}
              </ul>
              <button
                disabled={current}
                onClick={() => {
                  if (!p.purchasable) {
                    toast(SUBSCRIPTION_SOON_MESSAGE);
                    return;
                  }
                  toast("Você já está no plano FREE. Envie sua primeira música para começar.");
                }}
                className={cn(
                  "mt-6 rounded-sm py-2.5 text-sm font-semibold transition-opacity",
                  current
                    ? "cursor-default border border-border text-muted-foreground"
                    : p.highlight
                      ? "bg-electric text-primary-foreground hover:opacity-90"
                      : "border border-border text-foreground hover:border-electric",
                )}
              >
                {current ? "Plano atual" : p.cta}
              </button>
            </div>
          );
        })}
      </div>

      <section className="mt-14">
        <h2 className="text-2xl font-bold">Comparação de recursos</h2>
        <div className="mt-4 overflow-x-auto rounded-md border border-border">
          <table className="w-full min-w-[640px] border-collapse text-sm">
            <thead>
              <tr className="bg-surface text-left">
                <th scope="col" className="px-4 py-3 font-medium text-muted-foreground">
                  Recurso
                </th>
                <th scope="col" className="px-4 py-3 font-medium">
                  FREE
                </th>
                <th scope="col" className="px-4 py-3 font-medium text-electric">
                  PRO
                </th>
                <th scope="col" className="px-4 py-3 font-medium">
                  STUDIO
                </th>
              </tr>
            </thead>
            <tbody>
              {COMPARISON.map((row) => (
                <tr key={row.label} className="border-t border-border">
                  <th scope="row" className="px-4 py-3 text-left font-normal text-muted-foreground">
                    {row.label}
                  </th>
                  <td className="px-4 py-3 font-mono text-xs">
                    <CompareCell value={row.free} />
                  </td>
                  <td className="px-4 py-3 font-mono text-xs">
                    <CompareCell value={row.pro} />
                  </td>
                  <td className="px-4 py-3 font-mono text-xs">
                    <CompareCell value={row.studio} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-3 text-xs text-muted-foreground">{STUDIO_COMPARISON_NOTE}</p>
      </section>
    </AppShell>
  );
}
