import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { Waveform } from "@/components/Waveform";
import { formatTime } from "@/lib/audio-engine";
import { STEM_META } from "@/lib/mock-data";
import { PLAN_BY_ID } from "@/lib/pricing";
import { useAppState } from "@/lib/store";

export const Route = createFileRoute("/dashboard")({
  head: () => ({
    meta: [
      { title: "Projetos — SONICVOICE" },
      { name: "description", content: "Seus projetos de separação de stems, prontos para abrir no Studio." },
      { property: "og:title", content: "Projetos — SONICVOICE" },
      { property: "og:description", content: "Gerencie seus projetos de stems no SONICVOICE." },
    ],
  }),
  component: Dashboard,
});

function Dashboard() {
  const projects = useAppState((s) => s.projects);
  const user = useAppState((s) => s.user);
  const plan = PLAN_BY_ID[user?.plan ?? "free"];
  const usedThisMonth =
    plan.monthlyTracks === "unlimited"
      ? projects.length
      : Math.min(projects.length, plan.monthlyTracks);
  const monthlyUsageLabel =
    plan.monthlyTracks === "unlimited" ? `${usedThisMonth}/∞` : `${usedThisMonth}/${plan.monthlyTracks}`;

  return (
    <AppShell>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="font-mono text-xs uppercase tracking-[0.3em] text-electric">Biblioteca</p>
          <h1 className="mt-3 text-4xl font-bold">
            {user ? `Olá, ${user.name}` : "Seus projetos"}
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            {projects.length} sessões separadas · plano {user?.plan ?? "free"}
          </p>
        </div>
        <Link
          to="/upload"
          className="rounded-sm bg-electric px-5 py-2.5 text-sm font-semibold text-primary-foreground"
        >
          + Nova música
        </Link>
      </div>

      <div className="mt-6 grid grid-cols-2 gap-px overflow-hidden rounded-md border border-border bg-border md:grid-cols-4">
        {[
          { k: "Separações este mês", v: monthlyUsageLabel },
          { k: "Stems gerados", v: `${projects.length * 4}` },
          { k: "Tempo de áudio", v: formatTime(projects.reduce((a, p) => a + p.durationSec, 0)) },
          { k: "Exportações", v: "12" },
        ].map((s) => (
          <div key={s.k} className="bg-surface px-5 py-4">
            <p className="text-xs uppercase tracking-wider text-muted-foreground">{s.k}</p>
            <p className="mt-1 font-mono text-2xl font-medium text-foreground">{s.v}</p>
          </div>
        ))}
      </div>

      <div className="mt-10 space-y-3">
        {projects.map((p) => (
          <Link
            key={p.id}
            to="/studio/$projectId"
            params={{ projectId: p.id }}
            className="group flex items-center gap-6 rounded-md border border-border bg-surface p-4 transition-colors hover:border-electric"
          >
            <span
              className="h-14 w-14 shrink-0 rounded-sm"
              style={{
                background: `linear-gradient(135deg, oklch(0.7 0.18 ${p.coverHue}), oklch(0.25 0.05 ${p.coverHue}))`,
              }}
              aria-hidden
            />
            <div className="w-52 shrink-0">
              <h2 className="truncate text-base font-semibold text-foreground">{p.title}</h2>
              <p className="truncate text-xs text-muted-foreground">{p.artist}</p>
            </div>
            <div className="hidden min-w-0 flex-1 md:block">
              <Waveform
                seed={STEM_META.vocals.seed + p.coverHue}
                color="var(--electric)"
                progress={0}
                height={36}
                bars={90}
              />
            </div>
            <div className="ml-auto flex shrink-0 items-center gap-6 font-mono text-xs text-muted-foreground">
              <span>{p.bpm} BPM</span>
              <span>{p.keySignature}</span>
              <span>{formatTime(p.durationSec)}</span>
              <span className="rounded-full bg-electric-soft px-2.5 py-1 text-electric">Pronto</span>
            </div>
          </Link>
        ))}
      </div>
    </AppShell>
  );
}
