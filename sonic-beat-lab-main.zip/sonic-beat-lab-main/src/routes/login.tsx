import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Logo } from "@/components/AppShell";
import { actions } from "@/lib/store";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Entrar — SONICVOICE" },
      { name: "description", content: "Acesse sua conta SONICVOICE e volte para seus projetos de stems." },
      { property: "og:title", content: "Entrar — SONICVOICE" },
      { property: "og:description", content: "Acesse sua conta SONICVOICE." },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("produtor@sonicvoice.app");
  const [password, setPassword] = useState("demo1234");
  const [error, setError] = useState("");

  return (
    <AuthLayout title="Bem-vindo de volta" subtitle="Entre para acessar seus stems e sessões do Studio.">
      <form
        className="space-y-4"
        onSubmit={(e) => {
          e.preventDefault();
          if (!email.includes("@") || password.length < 4) {
            setError("Informe um e-mail válido e uma senha com pelo menos 4 caracteres.");
            return;
          }
          actions.signIn(email);
          navigate({ to: "/dashboard" });
        }}
      >
        <Field label="E-mail" id="email" type="email" value={email} onChange={setEmail} />
        <Field label="Senha" id="password" type="password" value={password} onChange={setPassword} />
        {error && (
          <p role="alert" className="text-sm text-destructive">
            {error}
          </p>
        )}
        <button
          type="submit"
          className="w-full rounded-sm bg-electric py-3 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90"
        >
          Entrar
        </button>
      </form>
      <p className="mt-6 text-sm text-muted-foreground">
        Ainda não tem conta?{" "}
        <Link to="/signup" className="text-electric hover:underline">
          Criar conta
        </Link>
      </p>
    </AuthLayout>
  );
}

export function AuthLayout({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle: string;
  children: React.ReactNode;
}) {
  return (
    <div className="relative flex min-h-screen flex-col bg-background">
      <div className="grid-noise pointer-events-none absolute inset-0 opacity-50" aria-hidden />
      <div className="relative px-6 py-6">
        <Logo />
      </div>
      <div className="relative flex flex-1 items-center justify-center px-6 pb-20">
        <div className="w-full max-w-sm rounded-md border border-border bg-surface p-8">
          <h1 className="text-2xl font-bold">{title}</h1>
          <p className="mb-6 mt-2 text-sm text-muted-foreground">{subtitle}</p>
          {children}
        </div>
      </div>
    </div>
  );
}

export function Field({
  label,
  id,
  type = "text",
  value,
  onChange,
}: {
  label: string;
  id: string;
  type?: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <div>
      <label htmlFor={id} className="mb-1.5 block text-xs font-medium uppercase tracking-wider text-muted-foreground">
        {label}
      </label>
      <input
        id={id}
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-sm border border-input bg-background px-3 py-2.5 text-sm text-foreground outline-none transition-colors focus:border-electric"
      />
    </div>
  );
}
