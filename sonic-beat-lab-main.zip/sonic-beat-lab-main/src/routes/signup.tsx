import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { actions } from "@/lib/store";
import { AuthLayout, Field } from "./login";

export const Route = createFileRoute("/signup")({
  head: () => ({
    meta: [
      { title: "Criar conta — SONICVOICE" },
      { name: "description", content: "Crie sua conta gratuita e separe até 5 músicas por mês no SONICVOICE." },
      { property: "og:title", content: "Criar conta — SONICVOICE" },
      { property: "og:description", content: "Crie sua conta gratuita no SONICVOICE." },
    ],
  }),
  component: SignupPage,
});

function SignupPage() {
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  return (
    <AuthLayout title="Criar conta" subtitle="5 músicas por mês no plano Free. Sem cartão de crédito.">
      <form
        className="space-y-4"
        onSubmit={(e) => {
          e.preventDefault();
          if (!name.trim() || !email.includes("@") || password.length < 4) {
            setError("Preencha nome, e-mail válido e senha com pelo menos 4 caracteres.");
            return;
          }
          actions.signIn(email, name.trim());
          navigate({ to: "/dashboard" });
        }}
      >
        <Field label="Nome" id="name" value={name} onChange={setName} />
        <Field label="E-mail" id="email" type="email" value={email} onChange={setEmail} />
        <Field label="Senha" id="password" type="password" value={password} onChange={setPassword} />
        {error && (
          <p role="alert" className="text-sm text-destructive">
            {error}
          </p>
        )}
        <button
          type="submit"
          className="w-full rounded-sm bg-electric py-3 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90"
        >
          Criar conta
        </button>
      </form>
      <p className="mt-6 text-sm text-muted-foreground">
        Já tem conta?{" "}
        <Link to="/login" className="text-electric hover:underline">
          Entrar
        </Link>
      </p>
    </AuthLayout>
  );
}
