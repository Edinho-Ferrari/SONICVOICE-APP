import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useReducer, useState } from "react";
import { AppShell } from "@/components/AppShell";
import { Waveform } from "@/components/Waveform";
import { MockAudioEngine, formatTime, isAudible, type StemId } from "@/lib/audio-engine";
import { STEM_META, STEM_ORDER } from "@/lib/mock-data";
import { getProject } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/studio/$projectId")({
  head: () => ({
    meta: [
      { title: "Studio — SONICVOICE" },
      { name: "description", content: "Mixe vocal, bateria, baixo e instrumentos com loop, metrônomo e exportação." },
      { property: "og:title", content: "Studio — SONICVOICE" },
      { property: "og:description", content: "Studio de mixagem de stems no navegador." },
    ],
  }),
  component: Studio,
});

const KEYS = ["C maj", "G maj", "D maj", "A maj", "F maj", "A min", "E min", "D min", "B min"];

function Studio() {
  const { projectId } = Route.useParams();
  const project = getProject(projectId);
  const [, force] = useReducer((n: number) => n + 1, 0);
  const [exporting, setExporting] = useState(false);

  const engine = useMemo(
    () =>
      new MockAudioEngine({
        duration: project.durationSec,
        bpm: project.bpm,
        keySignature: project.keySignature,
      }),
    [project.durationSec, project.bpm, project.keySignature],
  );

  useEffect(() => {
    const unsub = engine.subscribe(force);
    return () => {
      unsub();
      engine.dispose();
    };
  }, [engine]);

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.code === "Space" && !(e.target as HTMLElement)?.closest("input, select, button")) {
        e.preventDefault();
        engine.toggle();
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [engine]);

  const t = engine.transport;
  const progress = t.duration ? t.position / t.duration : 0;

  return (
    <AppShell wide>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <Link to="/dashboard" className="font-mono text-xs uppercase tracking-[0.3em] text-electric">
            ← Projetos
          </Link>
          <h1 className="mt-3 text-3xl font-bold">{project.title}</h1>
          <p className="text-sm text-muted-foreground">
            {project.artist} · 4 stems · {formatTime(project.durationSec)}
          </p>
        </div>
        <button
          onClick={() => setExporting(true)}
          className="rounded-sm bg-electric px-5 py-2.5 text-sm font-semibold text-primary-foreground"
        >
          Exportar
        </button>
      </div>

      <div className="mt-6 grid gap-4 xl:grid-cols-[1fr_320px]">
        <section className="space-y-4">
          {/* Transport */}
          <div className="flex flex-wrap items-center gap-4 rounded-md border border-border bg-surface px-5 py-4">
            <button
              onClick={() => engine.toggle()}
              aria-label={t.playing ? "Pausar" : "Reproduzir"}
              className="flex h-11 w-11 items-center justify-center rounded-full bg-electric text-primary-foreground"
            >
              {t.playing ? (
                <span className="flex gap-1">
                  <span className="h-4 w-[3px] bg-current" />
                  <span className="h-4 w-[3px] bg-current" />
                </span>
              ) : (
                <span className="ml-0.5 h-0 w-0 border-y-[7px] border-l-[11px] border-y-transparent border-l-current" />
              )}
            </button>
            <button
              onClick={() => engine.seek(0)}
              className="rounded-sm border border-border px-3 py-2 text-xs hover:border-electric"
            >
              Início
            </button>
            <span className="font-mono text-2xl tabular-nums">
              {formatTime(t.position)}
              <span className="text-sm text-muted-foreground"> / {formatTime(t.duration)}</span>
            </span>

            <div className="ml-auto flex flex-wrap items-center gap-3">
              <label className="flex items-center gap-2 text-xs uppercase tracking-wider text-muted-foreground">
                BPM
                <input
                  type="number"
                  min={40}
                  max={220}
                  value={t.bpm}
                  onChange={(e) => engine.setBpm(Number(e.target.value))}
                  className="w-20 rounded-sm border border-input bg-background px-2 py-1.5 text-center font-mono text-sm text-foreground focus:border-electric"
                />
              </label>
              <label className="flex items-center gap-2 text-xs uppercase tracking-wider text-muted-foreground">
                Tom
                <select
                  value={t.keySignature}
                  onChange={(e) => engine.setKey(e.target.value)}
                  className="rounded-sm border border-input bg-background px-2 py-1.5 font-mono text-sm text-foreground focus:border-electric"
                >
                  {[...new Set([t.keySignature, ...KEYS])].map((k) => (
                    <option key={k} value={k}>
                      {k}
                    </option>
                  ))}
                </select>
              </label>
              <Toggle active={t.loop} onClick={() => engine.setLoop(!t.loop)} label="Loop" />
              <Toggle
                active={t.metronome}
                onClick={() => engine.setMetronome(!t.metronome)}
                label="Metrônomo"
              />
            </div>
          </div>

          {t.loop && (
            <div className="flex flex-wrap items-center gap-4 rounded-md border border-electric/40 bg-electric-soft px-5 py-3 text-xs">
              <span className="font-mono uppercase tracking-wider text-electric">Região de loop</span>
              <label className="flex items-center gap-2 text-muted-foreground">
                Início
                <input
                  type="range"
                  min={0}
                  max={t.duration}
                  value={t.loopStart}
                  onChange={(e) => engine.setLoopRegion(Number(e.target.value), t.loopEnd)}
                  className="accent-[var(--electric)]"
                />
                <span className="font-mono text-foreground">{formatTime(t.loopStart)}</span>
              </label>
              <label className="flex items-center gap-2 text-muted-foreground">
                Fim
                <input
                  type="range"
                  min={0}
                  max={t.duration}
                  value={t.loopEnd}
                  onChange={(e) => engine.setLoopRegion(t.loopStart, Number(e.target.value))}
                  className="accent-[var(--electric)]"
                />
                <span className="font-mono text-foreground">{formatTime(t.loopEnd)}</span>
              </label>
              {t.metronome && (
                <span className="ml-auto flex items-center gap-2 text-electric">
                  <span
                    className={cn("h-2 w-2 rounded-full bg-electric", t.playing && "animate-ping")}
                    aria-hidden
                  />
                  click {t.bpm} bpm
                </span>
              )}
            </div>
          )}

          {/* Tracks */}
          <div className="space-y-3">
            {STEM_ORDER.map((id) => {
              const track = engine.tracks.find((x) => x.id === id)!;
              const audible = isAudible(track, engine.tracks);
              return (
                <div
                  key={id}
                  className="grid items-center gap-4 rounded-md border border-border bg-surface p-4 lg:grid-cols-[220px_1fr_200px]"
                >
                  <div className="flex items-center gap-3">
                    <span
                      className="h-9 w-1 rounded-full"
                      style={{ background: STEM_META[id].token }}
                      aria-hidden
                    />
                    <div>
                      <p className="text-sm font-semibold">{STEM_META[id].label}</p>
                      <p className="font-mono text-[11px] text-muted-foreground">
                        {audible ? "ativo" : "silenciado"}
                      </p>
                    </div>
                    <div className="ml-auto flex gap-1.5">
                      <SmallToggle
                        active={track.muted}
                        onClick={() => engine.setMuted(id, !track.muted)}
                        label="M"
                        title={`Mute ${STEM_META[id].label}`}
                      />
                      <SmallToggle
                        active={track.soloed}
                        onClick={() => engine.toggleSolo(id)}
                        label="S"
                        title={`Solo ${STEM_META[id].label}`}
                      />
                    </div>
                  </div>

                  <Waveform
                    seed={STEM_META[id].seed}
                    color={STEM_META[id].token}
                    progress={progress}
                    dimmed={!audible}
                    height={56}
                    onScrub={(r) => engine.seek(r * t.duration)}
                    ariaLabel={`Forma de onda ${STEM_META[id].label}`}
                  />

                  <div className="space-y-2">
                    <Slider
                      label="Vol"
                      value={track.volume}
                      min={0}
                      max={1}
                      step={0.01}
                      display={`${Math.round(track.volume * 100)}`}
                      onChange={(v) => engine.setVolume(id, v)}
                    />
                    <Slider
                      label="Pan"
                      value={track.pan}
                      min={-1}
                      max={1}
                      step={0.01}
                      display={
                        Math.abs(track.pan) < 0.02
                          ? "C"
                          : `${track.pan < 0 ? "L" : "R"}${Math.round(Math.abs(track.pan) * 100)}`
                      }
                      onChange={(v) => engine.setPan(id, v)}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Info / ferramentas */}
        <aside className="space-y-4">
          <div className="rounded-md border border-border bg-surface p-5">
            <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Informações
            </h2>
            <dl className="mt-4 space-y-2.5 text-sm">
              {[
                ["Duração", formatTime(t.duration)],
                ["BPM", String(t.bpm)],
                ["Tonalidade", t.keySignature],
                ["Compasso", "4/4"],
                ["Stems", "4 (vocal, drums, bass, other)"],
                ["Formato", "WAV 24-bit (simulado)"],
              ].map(([k, v]) => (
                <div key={k} className="flex justify-between gap-4 border-b border-border pb-2">
                  <dt className="text-muted-foreground">{k}</dt>
                  <dd className="font-mono text-right text-foreground">{v}</dd>
                </div>
              ))}
            </dl>
          </div>

          <div className="rounded-md border border-border bg-surface p-5">
            <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Ferramentas futuras
            </h2>
            <ul className="mt-4 space-y-2">
              {[
                "Mudança de tom sem alterar o tempo",
                "Time-stretch por região",
                "Redução de ruído no vocal",
                "Exportar MIDI da linha de baixo",
                "Colaboração em tempo real",
              ].map((f) => (
                <li
                  key={f}
                  className="flex items-center justify-between gap-3 rounded-sm border border-border px-3 py-2 text-xs text-muted-foreground"
                >
                  {f}
                  <span className="shrink-0 rounded-full bg-secondary px-2 py-0.5 text-[10px] uppercase tracking-wider">
                    em breve
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </aside>
      </div>

      {exporting && <ExportModal onClose={() => setExporting(false)} title={project.title} />}
    </AppShell>
  );
}

function Toggle({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        "rounded-sm border px-3 py-2 text-xs font-medium transition-colors",
        active
          ? "border-electric bg-electric-soft text-electric"
          : "border-border text-muted-foreground hover:text-foreground",
      )}
    >
      {label}
    </button>
  );
}

function SmallToggle({
  active,
  onClick,
  label,
  title,
}: {
  active: boolean;
  onClick: () => void;
  label: string;
  title: string;
}) {
  return (
    <button
      onClick={onClick}
      title={title}
      aria-label={title}
      aria-pressed={active}
      className={cn(
        "h-7 w-7 rounded-sm border text-[11px] font-bold transition-colors",
        active
          ? "border-electric bg-electric text-primary-foreground"
          : "border-border text-muted-foreground hover:text-foreground",
      )}
    >
      {label}
    </button>
  );
}

function Slider({
  label,
  value,
  min,
  max,
  step,
  display,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  display: string;
  onChange: (v: number) => void;
}) {
  return (
    <label className="flex items-center gap-2 text-[11px] uppercase tracking-wider text-muted-foreground">
      <span className="w-7">{label}</span>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="h-1 flex-1 accent-[var(--electric)]"
      />
      <span className="w-9 text-right font-mono text-foreground">{display}</span>
    </label>
  );
}

function ExportModal({ onClose, title }: { onClose: () => void; title: string }) {
  const [format, setFormat] = useState("wav");
  const [scope, setScope] = useState("stems");
  const [state, setState] = useState<"idle" | "running" | "done">("idle");
  const [pct, setPct] = useState(0);

  useEffect(() => {
    if (state !== "running") return;
    const started = performance.now();
    let raf = 0;
    const tick = (now: number) => {
      const p = Math.min(1, (now - started) / 3200);
      setPct(p);
      if (p < 1) raf = requestAnimationFrame(tick);
      else setState("done");
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [state]);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 p-6 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label="Exportar sessão"
    >
      <div className="w-full max-w-md rounded-md border border-border bg-surface p-6">
        <h2 className="text-xl font-bold">Exportar</h2>
        <p className="mt-1 truncate text-sm text-muted-foreground">{title}</p>

        {state !== "done" ? (
          <>
            <fieldset className="mt-6">
              <legend className="text-xs uppercase tracking-wider text-muted-foreground">Conteúdo</legend>
              <div className="mt-2 grid grid-cols-2 gap-2">
                {[
                  { id: "stems", label: "4 stems separados" },
                  { id: "mix", label: "Mixagem atual" },
                ].map((o) => (
                  <button
                    key={o.id}
                    onClick={() => setScope(o.id)}
                    aria-pressed={scope === o.id}
                    className={cn(
                      "rounded-sm border px-3 py-2 text-xs",
                      scope === o.id ? "border-electric bg-electric-soft text-electric" : "border-border",
                    )}
                  >
                    {o.label}
                  </button>
                ))}
              </div>
            </fieldset>

            <fieldset className="mt-4">
              <legend className="text-xs uppercase tracking-wider text-muted-foreground">Formato</legend>
              <div className="mt-2 grid grid-cols-3 gap-2">
                {["wav", "mp3", "flac"].map((f) => (
                  <button
                    key={f}
                    onClick={() => setFormat(f)}
                    aria-pressed={format === f}
                    className={cn(
                      "rounded-sm border px-3 py-2 font-mono text-xs uppercase",
                      format === f ? "border-electric bg-electric-soft text-electric" : "border-border",
                    )}
                  >
                    {f}
                  </button>
                ))}
              </div>
            </fieldset>

            {state === "running" && (
              <div className="mt-6">
                <div
                  className="h-1.5 overflow-hidden rounded-full bg-secondary"
                  role="progressbar"
                  aria-valuenow={Math.round(pct * 100)}
                  aria-label="Progresso da exportação"
                >
                  <div className="h-full bg-electric" style={{ width: `${pct * 100}%` }} />
                </div>
                <p className="mt-2 font-mono text-xs text-muted-foreground">
                  Renderizando… {Math.round(pct * 100)}%
                </p>
              </div>
            )}

            <div className="mt-6 flex justify-end gap-2">
              <button onClick={onClose} className="rounded-sm border border-border px-4 py-2 text-sm">
                Cancelar
              </button>
              <button
                onClick={() => setState("running")}
                disabled={state === "running"}
                className="rounded-sm bg-electric px-4 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-60"
              >
                {state === "running" ? "Exportando…" : "Exportar"}
              </button>
            </div>
          </>
        ) : (
          <div className="mt-8 text-center">
            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-electric-soft text-electric">
              ✓
            </div>
            <p className="mt-4 font-medium">Exportação concluída</p>
            <p className="mt-1 text-sm text-muted-foreground">
              {scope === "stems" ? "4 arquivos" : "1 arquivo"} em {format.toUpperCase()} (simulado).
            </p>
            <button
              onClick={onClose}
              className="mt-6 w-full rounded-sm bg-electric py-2.5 text-sm font-semibold text-primary-foreground"
            >
              Fechar
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
