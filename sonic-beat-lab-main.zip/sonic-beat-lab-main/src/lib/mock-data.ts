import type { StemId } from "./audio-engine";

export interface Project {
  id: string;
  title: string;
  artist: string;
  durationSec: number;
  bpm: number;
  keySignature: string;
  createdAt: string;
  status: "ready" | "processing" | "failed";
  coverHue: number;
}

export const MOCK_PROJECTS: Project[] = [
  {
    id: "prj_neonrain",
    title: "Neon Rain",
    artist: "Lua Vermelha",
    durationSec: 212,
    bpm: 124,
    keySignature: "A min",
    createdAt: "2026-08-28",
    status: "ready",
    coverHue: 256,
  },
  {
    id: "prj_saltalto",
    title: "Salto Alto",
    artist: "Duo Mareh",
    durationSec: 187,
    bpm: 98,
    keySignature: "F maj",
    createdAt: "2026-08-21",
    status: "ready",
    coverHue: 330,
  },
  {
    id: "prj_asfalto",
    title: "Asfalto Molhado",
    artist: "Trio Norte",
    durationSec: 244,
    bpm: 142,
    keySignature: "D min",
    createdAt: "2026-08-14",
    status: "ready",
    coverHue: 175,
  },
  {
    id: "prj_verao",
    title: "Verão Sintético",
    artist: "Kaya B.",
    durationSec: 165,
    bpm: 110,
    keySignature: "G maj",
    createdAt: "2026-07-30",
    status: "ready",
    coverHue: 85,
  },
];

export const DEMO_TRACKS = [
  { name: "Neon Rain — Lua Vermelha", size: "8.4 MB", bpm: 124, key: "A min", duration: 212 },
  { name: "Salto Alto — Duo Mareh", size: "6.9 MB", bpm: 98, key: "F maj", duration: 187 },
  { name: "Asfalto Molhado — Trio Norte", size: "9.7 MB", bpm: 142, key: "D min", duration: 244 },
];

export const PROCESSING_STAGES = [
  { label: "Enviando arquivo", detail: "Transferência segura para a fila de processamento" },
  { label: "Analisando espectro", detail: "Detecção de BPM, tonalidade e estrutura" },
  { label: "Separando stems", detail: "Isolando vocal, bateria, baixo e demais instrumentos" },
  { label: "Renderizando waveforms", detail: "Gerando visualizações por track" },
  { label: "Finalizando sessão", detail: "Preparando o Studio" },
];

export const STEM_ORDER: StemId[] = ["vocals", "drums", "bass", "other"];

export const STEM_META: Record<StemId, { label: string; token: string; seed: number }> = {
  vocals: { label: "Vocal", token: "var(--track-vocal)", seed: 11 },
  drums: { label: "Drums", token: "var(--track-drums)", seed: 29 },
  bass: { label: "Bass", token: "var(--track-bass)", seed: 47 },
  other: { label: "Other", token: "var(--track-other)", seed: 83 },
};

// Planos vivem em src/lib/pricing.ts (fonte de verdade única).

/** Waveform determinística por stem (sem áudio real). */
export function waveformBars(seed: number, count = 160): number[] {
  const bars: number[] = [];
  let s = seed;
  for (let i = 0; i < count; i++) {
    s = (s * 9301 + 49297) % 233280;
    const rnd = s / 233280;
    const envelope = 0.45 + 0.45 * Math.sin((i / count) * Math.PI * 3 + seed);
    bars.push(Math.max(0.08, Math.min(1, envelope * (0.5 + rnd * 0.9))));
  }
  return bars;
}
