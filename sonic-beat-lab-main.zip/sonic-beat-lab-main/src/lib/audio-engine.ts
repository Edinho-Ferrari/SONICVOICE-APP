/**
 * AudioEngine — abstração simulada.
 *
 * Nenhum áudio real é decodificado aqui. A interface foi desenhada para que
 * uma implementação real (Web Audio API + stems vindos do Supabase Storage)
 * possa substituir `MockAudioEngine` sem alterar a UI.
 */

export type StemId = "vocals" | "drums" | "bass" | "other";

export interface TrackState {
  id: StemId;
  name: string;
  volume: number; // 0..1
  pan: number; // -1..1
  muted: boolean;
  soloed: boolean;
}

export interface TransportState {
  playing: boolean;
  position: number; // segundos
  duration: number; // segundos
  bpm: number;
  keySignature: string;
  loop: boolean;
  loopStart: number;
  loopEnd: number;
  metronome: boolean;
}

export interface AudioEngine {
  readonly transport: TransportState;
  readonly tracks: TrackState[];
  play(): void;
  pause(): void;
  toggle(): void;
  seek(seconds: number): void;
  setVolume(id: StemId, volume: number): void;
  setPan(id: StemId, pan: number): void;
  setMuted(id: StemId, muted: boolean): void;
  toggleSolo(id: StemId): void;
  setBpm(bpm: number): void;
  setKey(key: string): void;
  setLoop(enabled: boolean): void;
  setLoopRegion(start: number, end: number): void;
  setMetronome(enabled: boolean): void;
  subscribe(listener: () => void): () => void;
  dispose(): void;
}

const DEFAULT_TRACKS: TrackState[] = [
  { id: "vocals", name: "Vocal", volume: 0.85, pan: 0, muted: false, soloed: false },
  { id: "drums", name: "Drums", volume: 0.8, pan: 0, muted: false, soloed: false },
  { id: "bass", name: "Bass", volume: 0.75, pan: 0, muted: false, soloed: false },
  { id: "other", name: "Other", volume: 0.7, pan: 0, muted: false, soloed: false },
];

export class MockAudioEngine implements AudioEngine {
  transport: TransportState;
  tracks: TrackState[];
  private listeners = new Set<() => void>();
  private raf: number | null = null;
  private lastTick = 0;

  constructor(opts: { duration: number; bpm: number; keySignature: string }) {
    this.transport = {
      playing: false,
      position: 0,
      duration: opts.duration,
      bpm: opts.bpm,
      keySignature: opts.keySignature,
      loop: false,
      loopStart: Math.round(opts.duration * 0.25),
      loopEnd: Math.round(opts.duration * 0.5),
      metronome: false,
    };
    this.tracks = DEFAULT_TRACKS.map((t) => ({ ...t }));
  }

  private emit() {
    this.listeners.forEach((l) => l());
  }

  subscribe(listener: () => void) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private tick = (now: number) => {
    const dt = (now - this.lastTick) / 1000;
    this.lastTick = now;
    const t = this.transport;
    let next = t.position + dt;
    if (t.loop && next >= t.loopEnd) next = t.loopStart;
    if (next >= t.duration) {
      next = t.duration;
      t.position = next;
      t.playing = false;
      this.raf = null;
      this.emit();
      return;
    }
    t.position = next;
    this.emit();
    this.raf = requestAnimationFrame(this.tick);
  };

  play() {
    if (this.transport.playing) return;
    if (this.transport.position >= this.transport.duration) this.transport.position = 0;
    this.transport.playing = true;
    this.lastTick = performance.now();
    this.raf = requestAnimationFrame(this.tick);
    this.emit();
  }

  pause() {
    this.transport.playing = false;
    if (this.raf !== null) cancelAnimationFrame(this.raf);
    this.raf = null;
    this.emit();
  }

  toggle() {
    this.transport.playing ? this.pause() : this.play();
  }

  seek(seconds: number) {
    this.transport.position = Math.min(Math.max(seconds, 0), this.transport.duration);
    this.emit();
  }

  private update(id: StemId, patch: Partial<TrackState>) {
    this.tracks = this.tracks.map((t) => (t.id === id ? { ...t, ...patch } : t));
    this.emit();
  }

  setVolume(id: StemId, volume: number) {
    this.update(id, { volume });
  }
  setPan(id: StemId, pan: number) {
    this.update(id, { pan });
  }
  setMuted(id: StemId, muted: boolean) {
    this.update(id, { muted });
  }
  toggleSolo(id: StemId) {
    const current = this.tracks.find((t) => t.id === id);
    this.update(id, { soloed: !current?.soloed });
  }
  setBpm(bpm: number) {
    this.transport.bpm = bpm;
    this.emit();
  }
  setKey(key: string) {
    this.transport.keySignature = key;
    this.emit();
  }
  setLoop(enabled: boolean) {
    this.transport.loop = enabled;
    this.emit();
  }
  setLoopRegion(start: number, end: number) {
    this.transport.loopStart = start;
    this.transport.loopEnd = end;
    this.emit();
  }
  setMetronome(enabled: boolean) {
    this.transport.metronome = enabled;
    this.emit();
  }
  dispose() {
    this.pause();
    this.listeners.clear();
  }
}

/** true quando a track deve soar, considerando mute e solo global. */
export function isAudible(track: TrackState, tracks: TrackState[]) {
  const anySolo = tracks.some((t) => t.soloed);
  if (track.muted) return false;
  return anySolo ? track.soloed : true;
}

export function formatTime(seconds: number) {
  const s = Math.max(0, Math.floor(seconds));
  const m = Math.floor(s / 60);
  return `${String(m).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
}
