/**
 * Fonte de verdade única de planos/preços/limites/benefícios.
 * Estruturado para ser trocado por uma tabela `plans` (Supabase) sem mexer na UI.
 */

export type PlanId = "free" | "pro" | "studio";

export interface Plan {
  id: PlanId;
  name: string;
  price: string;
  period: string;
  /** Linhas extras de cobrança (ex.: parcelamento do Studio). */
  billingNotes?: string[];
  tagline: string;
  badge?: string;
  monthlyTracks: number | "unlimited";
  monthlyTracksLabel: string;
  features: string[];
  cta: string;
  /** Assinatura ainda não disponível — apenas informa o usuário. */
  purchasable: boolean;
  highlight?: boolean;
}

export const SUBSCRIPTION_SOON_MESSAGE =
  "Assinatura em breve. O sistema de pagamentos será disponibilizado em uma próxima etapa.";

export const PLANS: Plan[] = [
  {
    id: "free",
    name: "FREE",
    price: "R$ 0",
    period: "Grátis",
    tagline: "Comece gratuitamente",
    badge: "Comece gratuitamente",
    monthlyTracks: 5,
    monthlyTracksLabel: "5 músicas/mês",
    features: [
      "5 músicas/mês",
      "4 stems (Vocal, Drums, Bass, Other)",
      "Exportação em MP3",
      "Studio básico",
      "Volume, mute, solo e pan",
      "Player e waveform por track",
      "Sem cartão de crédito",
    ],
    cta: "Começar grátis",
    purchasable: true,
  },
  {
    id: "pro",
    name: "PRO",
    price: "R$ 4,99",
    period: "/mês",
    tagline: "Para quem precisa de mais recursos para trabalhar com música",
    badge: "MAIS POPULAR",
    monthlyTracks: 30,
    monthlyTracksLabel: "30 músicas/mês",
    features: [
      "30 músicas/mês",
      "Tudo do Free",
      "Exportação em WAV e MP3",
      "Detecção e controle de BPM",
      "Detecção e controle de Key/Tonalidade",
      "Loop",
      "Metrônomo",
      "Studio completo com controles avançados",
    ],
    cta: "Assinar PRO",
    purchasable: false,
    highlight: true,
  },
  {
    id: "studio",
    name: "STUDIO",
    price: "R$ 9,90",
    period: "/mês",
    billingNotes: [
      "Por mês, pago anualmente",
      "Parcelado no cartão ou total à vista no cartão ou Pix.",
    ],
    tagline: "Para produção musical avançada",
    monthlyTracks: "unlimited",
    monthlyTracksLabel: "Separações ilimitadas",
    features: [
      "Todos os recursos do Pro",
      "Separações ilimitadas",
      "Stems avançados ilimitados",
      "Exportação em WAV e MP3",
      "Ferramentas AI",
      "AI Mix",
      "AI Master",
      "Recursos avançados",
      "Multifaixa personalizada",
    ],
    cta: "Assinar STUDIO",
    purchasable: false,
  },
];

export const PLAN_BY_ID: Record<PlanId, Plan> = PLANS.reduce(
  (acc, p) => ({ ...acc, [p.id]: p }),
  {} as Record<PlanId, Plan>,
);

export const FREE_MONTHLY_LIMIT = 5;

export type CompareValue = string | boolean;

export const COMPARISON: { label: string; free: CompareValue; pro: CompareValue; studio: CompareValue }[] = [
  { label: "Músicas por mês", free: "5", pro: "30", studio: "Ilimitado" },
  { label: "Stems", free: "4", pro: "4", studio: "Avançados ilimitados" },
  { label: "Exportação MP3", free: true, pro: true, studio: true },
  { label: "Exportação WAV", free: false, pro: true, studio: true },
  { label: "Detecção e controle de BPM", free: false, pro: true, studio: true },
  { label: "Key / Tonalidade", free: false, pro: true, studio: true },
  { label: "Loop", free: false, pro: true, studio: true },
  { label: "Metrônomo", free: false, pro: true, studio: true },
  { label: "Ferramentas AI", free: false, pro: false, studio: true },
  { label: "AI Mix", free: false, pro: false, studio: true },
  { label: "AI Master", free: false, pro: false, studio: true },
  { label: "Multifaixa personalizada", free: false, pro: false, studio: true },
];

export const STUDIO_COMPARISON_NOTE =
  "STUDIO: R$ 9,90 por mês, pago anualmente. Parcelado no cartão ou total à vista no cartão ou Pix.";
