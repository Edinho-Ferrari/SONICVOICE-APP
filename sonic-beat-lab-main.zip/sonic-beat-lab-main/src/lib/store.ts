import { useSyncExternalStore } from "react";
import { MOCK_PROJECTS, type Project } from "./mock-data";
import type { PlanId } from "./pricing";

/**
 * Estado global mockado. Organizado como store único para que, no futuro,
 * cada slice possa ser trocado por queries do Supabase sem mexer na UI.
 */

export interface SessionUser {
  name: string;
  email: string;
  plan: PlanId;
}

export interface PendingUpload {
  fileName: string;
  sizeLabel: string;
  bpm: number;
  keySignature: string;
  durationSec: number;
}

interface AppState {
  user: SessionUser | null;
  projects: Project[];
  pendingUpload: PendingUpload | null;
  settings: {
    autoDetectBpm: boolean;
    highQualityRender: boolean;
    emailUpdates: boolean;
    defaultFormat: "wav" | "mp3" | "flac";
  };
}

let state: AppState = {
  user: null,
  projects: MOCK_PROJECTS,
  pendingUpload: null,
  settings: {
    autoDetectBpm: true,
    highQualityRender: true,
    emailUpdates: false,
    defaultFormat: "wav",
  },
};

const listeners = new Set<() => void>();

function setState(patch: Partial<AppState>) {
  state = { ...state, ...patch };
  listeners.forEach((l) => l());
}

function subscribe(listener: () => void) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function useAppState<T>(selector: (s: AppState) => T): T {
  return useSyncExternalStore(
    subscribe,
    () => selector(state),
    () => selector(state),
  );
}

export const actions = {
  signIn(email: string, name?: string) {
    const fallback = email.split("@")[0]?.replace(/[._-]/g, " ");
    setState({
      user: {
        name: name || fallback || "Produtor",
        email,
        plan: "free",
      },
    });
  },

  signOut() {
    setState({ user: null });
  },
  setPlan(plan: SessionUser["plan"]) {
    if (!state.user) return;
    setState({ user: { ...state.user, plan } });
  },
  setPendingUpload(upload: PendingUpload | null) {
    setState({ pendingUpload: upload });
  },
  addProject(project: Project) {
    setState({ projects: [project, ...state.projects] });
  },
  updateSettings(patch: Partial<AppState["settings"]>) {
    setState({ settings: { ...state.settings, ...patch } });
  },
};

export function getProject(id: string): Project {
  return state.projects.find((p) => p.id === id) ?? state.projects[0] ?? MOCK_PROJECTS[0]!;
}
