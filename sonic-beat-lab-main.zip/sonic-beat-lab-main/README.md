# Sonic Voice Studio

Crie a primeira versão visual e funcional do SaaS web SONICVOICE conforme o briefing do usuário. Prioridade: frontend premium, totalmente navegável e responsivo, com dados mockados, sem backend, IA real ou pagamentos reais. Implemente as rotas landing, login, cadastro, dashboard, upload, processamento, studio, planos e configurações. Faça o fluxo completo funcionar: cadastro/login visual → dashboard → nova música/upload (seletor/mock) → processamento animado → studio. No Studio, inclua tracks Vocal/Drums/Bass/Other com waveforms próprias em CSS/SVG, mute/solo/volume/pan com estados, transport play/pause com tempo simulado, BPM e tonalidade editáveis, loop e metrônomo, painel de informações/ferramentas futuras e modal de exportação com conclusão simulada. Crie AudioEngine abstrato simulado e organize mocks/estado/componentes para futura integração com Supabase. Use identidade própria: quase preto, superfícies escuras, branco/cinza e azul elétrico pontual, sem parecer dashboard genérico, com boa acessibilidade e desktop-first.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://sonic-beat-lab.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/59324d56-ab75-41dc-9acb-e3f39762c1f9).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
